package net.mcreator.drugsgems.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.drugsgems.procedures.StrengthofHellfireEffectEffectStartedappliedProcedure;

public class StrengthofHellfireEffectMobEffect extends MobEffect {
	public StrengthofHellfireEffectMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -13434880);
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("block.beacon.activate")));
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		StrengthofHellfireEffectEffectStartedappliedProcedure.execute(entity);
	}
}