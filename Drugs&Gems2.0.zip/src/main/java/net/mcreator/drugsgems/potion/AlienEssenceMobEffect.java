package net.mcreator.drugsgems.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.drugsgems.DrugsGemsMod;

public class AlienEssenceMobEffect extends MobEffect {
	public AlienEssenceMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -13434829);
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("intentionally_empty")));
		this.addAttributeModifier(Attributes.SAFE_FALL_DISTANCE, ResourceLocation.fromNamespaceAndPath(DrugsGemsMod.MODID, "effect.alien_essence_0"), 1000, AttributeModifier.Operation.ADD_VALUE);
	}
}