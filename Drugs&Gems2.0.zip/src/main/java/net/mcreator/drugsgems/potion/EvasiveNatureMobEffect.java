package net.mcreator.drugsgems.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.drugsgems.procedures.EvasiveNatureOnEffectActiveTickProcedure;
import net.mcreator.drugsgems.procedures.EvasiveNatureEffectStartedappliedProcedure;

public class EvasiveNatureMobEffect extends MobEffect {
	public EvasiveNatureMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -1);
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.warden.sonic_boom")));
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		EvasiveNatureEffectStartedappliedProcedure.execute(entity);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		EvasiveNatureOnEffectActiveTickProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
		return super.applyEffectTick(entity, amplifier);
	}
}