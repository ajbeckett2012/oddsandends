package net.mcreator.drugsgems.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.drugsgems.procedures.OverdosingEffectOnEffectActiveTickProcedure;
import net.mcreator.drugsgems.procedures.OverdosingEffectActiveTickConditionProcedure;

public class OverdosingEffectMobEffect extends MobEffect {
	public OverdosingEffectMobEffect() {
		super(MobEffectCategory.HARMFUL, -15525359);
	}

	@Override
	public ParticleOptions createParticleOptions(MobEffectInstance mobEffectInstance) {
		return ParticleTypes.MYCELIUM;
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return OverdosingEffectActiveTickConditionProcedure.execute(amplifier, duration);
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		OverdosingEffectOnEffectActiveTickProcedure.execute(entity.level(), entity);
		return super.applyEffectTick(entity, amplifier);
	}
}