package net.mcreator.drugsgems.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.drugsgems.procedures.GiftsoftheWickedOnEffectActiveTickProcedure;
import net.mcreator.drugsgems.procedures.GiftsoftheWickedEffectStartedappliedProcedure;

public class GiftsoftheWickedMobEffect extends MobEffect {
	public GiftsoftheWickedMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -13624829);
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("block.conduit.activate")));
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		GiftsoftheWickedEffectStartedappliedProcedure.execute(entity);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		GiftsoftheWickedOnEffectActiveTickProcedure.execute(entity);
		return super.applyEffectTick(entity, amplifier);
	}
}