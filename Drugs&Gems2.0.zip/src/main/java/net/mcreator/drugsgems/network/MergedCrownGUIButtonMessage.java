package net.mcreator.drugsgems.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.drugsgems.procedures.StrengthofHellfireChosenProcedure;
import net.mcreator.drugsgems.procedures.GiftsoftheWickedChosenProcedure;
import net.mcreator.drugsgems.procedures.EvasiveNatureChosenProcedure;
import net.mcreator.drugsgems.procedures.AlienEssenceChosenProcedure;
import net.mcreator.drugsgems.DrugsGemsMod;

@EventBusSubscriber
public record MergedCrownGUIButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {

	public static final Type<MergedCrownGUIButtonMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(DrugsGemsMod.MODID, "merged_crown_gui_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, MergedCrownGUIButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, MergedCrownGUIButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new MergedCrownGUIButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));
	@Override
	public Type<MergedCrownGUIButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final MergedCrownGUIButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> handleButtonAction(context.player(), message.buttonID, message.x, message.y, message.z)).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			StrengthofHellfireChosenProcedure.execute(world, entity);
		}
		if (buttonID == 1) {

			AlienEssenceChosenProcedure.execute(world, entity);
		}
		if (buttonID == 2) {

			EvasiveNatureChosenProcedure.execute(world, entity);
		}
		if (buttonID == 3) {

			GiftsoftheWickedChosenProcedure.execute(world, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		DrugsGemsMod.addNetworkMessage(MergedCrownGUIButtonMessage.TYPE, MergedCrownGUIButtonMessage.STREAM_CODEC, MergedCrownGUIButtonMessage::handleData);
	}
}