package net.mcreator.drugsgems.block;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;

public class PaleDiamondDeepslateOreBlock extends Block {
	public PaleDiamondDeepslateOreBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(1.1f, 3f).requiresCorrectToolForDrops());
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}
}