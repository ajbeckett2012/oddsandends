/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.drugsgems.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.drugsgems.entity.TweakerEntity;
import net.mcreator.drugsgems.entity.HatManEntity;
import net.mcreator.drugsgems.DrugsGemsMod;

@EventBusSubscriber
public class DrugsGemsModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, DrugsGemsMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<HatManEntity>> HAT_MAN = register("hat_man",
			EntityType.Builder.<HatManEntity>of(HatManEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 2f));
	public static final DeferredHolder<EntityType<?>, EntityType<TweakerEntity>> TWEAKER = register("tweaker",
			EntityType.Builder.<TweakerEntity>of(TweakerEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		HatManEntity.init(event);
		TweakerEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(HAT_MAN.get(), HatManEntity.createAttributes().build());
		event.put(TWEAKER.get(), TweakerEntity.createAttributes().build());
	}
}