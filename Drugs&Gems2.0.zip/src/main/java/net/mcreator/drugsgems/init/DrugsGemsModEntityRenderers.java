/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.drugsgems.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.drugsgems.client.renderer.TweakerRenderer;
import net.mcreator.drugsgems.client.renderer.HatManRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class DrugsGemsModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(DrugsGemsModEntities.HAT_MAN.get(), HatManRenderer::new);
		event.registerEntityRenderer(DrugsGemsModEntities.TWEAKER.get(), TweakerRenderer::new);
	}
}