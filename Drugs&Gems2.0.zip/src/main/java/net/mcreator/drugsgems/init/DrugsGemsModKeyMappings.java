/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.drugsgems.init;

import org.lwjgl.glfw.GLFW;

import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.drugsgems.network.MergedCrownKeybindMessage;
import net.mcreator.drugsgems.network.AlienEssenceTeleportingKeybindMessage;

@EventBusSubscriber(Dist.CLIENT)
public class DrugsGemsModKeyMappings {
	public static final KeyMapping MERGED_CROWN_KEYBIND = new KeyMapping("key.drugs__gems.merged_crown_keybind", GLFW.GLFW_KEY_M, "key.categories.gameplay") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				PacketDistributor.sendToServer(new MergedCrownKeybindMessage(0, 0));
				MergedCrownKeybindMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping ALIEN_ESSENCE_TELEPORTING_KEYBIND = new KeyMapping("key.drugs__gems.alien_essence_teleporting_keybind", GLFW.GLFW_KEY_R, "key.categories.gameplay") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				PacketDistributor.sendToServer(new AlienEssenceTeleportingKeybindMessage(0, 0));
				AlienEssenceTeleportingKeybindMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(MERGED_CROWN_KEYBIND);
		event.register(ALIEN_ESSENCE_TELEPORTING_KEYBIND);
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onClientTick(ClientTickEvent.Post event) {
			if (Minecraft.getInstance().screen == null) {
				MERGED_CROWN_KEYBIND.consumeClick();
				ALIEN_ESSENCE_TELEPORTING_KEYBIND.consumeClick();
			}
		}
	}
}