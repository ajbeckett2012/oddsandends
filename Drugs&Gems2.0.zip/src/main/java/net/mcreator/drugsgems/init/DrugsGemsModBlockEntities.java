/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.drugsgems.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.items.wrapper.SidedInvWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.drugsgems.block.entity.TraySolidBlockEntity;
import net.mcreator.drugsgems.block.entity.TrayLiquidBlockEntity;
import net.mcreator.drugsgems.block.entity.TrayBlockEntity;
import net.mcreator.drugsgems.block.entity.CokePileBlockEntity;
import net.mcreator.drugsgems.DrugsGemsMod;

@EventBusSubscriber
public class DrugsGemsModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, DrugsGemsMod.MODID);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CokePileBlockEntity>> COKE_PILE = register("coke_pile", DrugsGemsModBlocks.COKE_PILE, CokePileBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TrayBlockEntity>> TRAY = register("tray", DrugsGemsModBlocks.TRAY, TrayBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TrayLiquidBlockEntity>> TRAY_LIQUID = register("tray_liquid", DrugsGemsModBlocks.TRAY_LIQUID, TrayLiquidBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TraySolidBlockEntity>> TRAY_SOLID = register("tray_solid", DrugsGemsModBlocks.TRAY_SOLID, TraySolidBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> DeferredHolder<BlockEntityType<?>, BlockEntityType<T>> register(String registryname, DeferredHolder<Block, Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, COKE_PILE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, TRAY.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, TRAY_LIQUID.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, TRAY_SOLID.get(), SidedInvWrapper::new);
	}
}