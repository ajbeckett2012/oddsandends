/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.drugsgems.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.drugsgems.potion.*;
import net.mcreator.drugsgems.DrugsGemsMod;

public class DrugsGemsModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, DrugsGemsMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> HIGH = REGISTRY.register("high", () -> new HighMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> OVERDOSING_EFFECT = REGISTRY.register("overdosing_effect", () -> new OverdosingEffectMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> STRENGTHOF_HELLFIRE_EFFECT = REGISTRY.register("strengthof_hellfire_effect", () -> new StrengthofHellfireEffectMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ALIEN_ESSENCE = REGISTRY.register("alien_essence", () -> new AlienEssenceMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> EVASIVE_NATURE = REGISTRY.register("evasive_nature", () -> new EvasiveNatureMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> GIFTSOFTHE_WICKED = REGISTRY.register("giftsofthe_wicked", () -> new GiftsoftheWickedMobEffect());
}