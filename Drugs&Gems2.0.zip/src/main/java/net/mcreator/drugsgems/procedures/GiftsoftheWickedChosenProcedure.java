package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.network.chat.Component;

import net.mcreator.drugsgems.init.DrugsGemsModMobEffects;
import net.mcreator.drugsgems.DrugsGemsMod;

public class GiftsoftheWickedChosenProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player)
			_player.closeContainer();
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(DrugsGemsModMobEffects.GIFTSOFTHE_WICKED, 24000, 1, false, false));
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Gifts of the Wicked has been chosen for the day."), false);
		entity.getPersistentData().putString("CrownCooldown", "true");
		DrugsGemsMod.queueServerWork(24000, () -> {
			entity.getPersistentData().putString("CrownCooldown", "false");
		});
	}
}