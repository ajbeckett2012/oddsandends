package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.drugsgems.init.DrugsGemsModMobEffects;
import net.mcreator.drugsgems.DrugsGemsMod;

public class AcidPlayerFinishesUsingItemProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 3000, 9, false, false));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(DrugsGemsModMobEffects.HIGH, 3000, 0, false, false));
		DrugsGemsMod.queueServerWork(200, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(400, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(760, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(900, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(940, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(1150, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(1320, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(1500, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(1630, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(1720, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(1890, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(2530, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(2600, () -> {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1,
							Mth.nextInt(RandomSource.create(), -1, 2));
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("drugs__gems:horrorvoices")), SoundSource.NEUTRAL, 1, Mth.nextInt(RandomSource.create(), -1, 2),
							false);
				}
			}
		});
	}
}