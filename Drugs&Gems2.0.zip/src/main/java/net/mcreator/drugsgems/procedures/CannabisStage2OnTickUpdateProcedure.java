package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.drugsgems.init.DrugsGemsModBlocks;

public class CannabisStage2OnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		sx = -3;
		found = false;
		for (int index0 = 0; index0 < 10; index0++) {
			sy = -3;
			for (int index1 = 0; index1 < 10; index1++) {
				sz = -3;
				for (int index2 = 0; index2 < 10; index2++) {
					if ((world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == DrugsGemsModBlocks.FAN_ON.get()) {
						found = true;
					}
					sz = sz + 1;
				}
				sy = sy + 1;
			}
			sx = sx + 1;
		}
		if (found == true) {
			sy = 0;
			found = false;
			for (int index3 = 0; index3 < 6; index3++) {
				if ((world.getBlockState(BlockPos.containing(x, y + sy, z))).getBlock() == DrugsGemsModBlocks.UV_LIGHT_ON.get()) {
					found = true;
				}
				sy = sy + 1;
			}
			if (found == true) {
				if (Math.random() < 0.1) {
					{
						BlockPos _bp = BlockPos.containing(x, y, z);
						BlockState _bs = DrugsGemsModBlocks.CANNABIS_2_STAGE_3.get().defaultBlockState();
						BlockState _bso = world.getBlockState(_bp);
						for (Property<?> _propertyOld : _bso.getProperties()) {
							Property _propertyNew = _bs.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
							if (_propertyNew != null && _bs.getValue(_propertyNew) != null)
								try {
									_bs = _bs.setValue(_propertyNew, _bso.getValue(_propertyOld));
								} catch (Exception e) {
								}
						}
						world.setBlock(_bp, _bs, 3);
					}
				}
			}
		}
	}
}