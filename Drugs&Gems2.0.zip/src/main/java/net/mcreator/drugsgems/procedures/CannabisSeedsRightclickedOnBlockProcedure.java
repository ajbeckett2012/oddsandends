package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;

import net.mcreator.drugsgems.init.DrugsGemsModBlocks;

public class CannabisSeedsRightclickedOnBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, ItemStack itemstack) {
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		BlockState wheatBlock = Blocks.AIR.defaultBlockState();
		if (world.isEmptyBlock(BlockPos.containing(x, y + 1, z)) && (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.FARMLAND) {
			world.setBlock(BlockPos.containing(x, y + 1, z), DrugsGemsModBlocks.CANNABIS_2_STAGE_1.get().defaultBlockState(), 3);
			itemstack.shrink(1);
		}
	}
}