package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;

import net.mcreator.drugsgems.init.DrugsGemsModBlocks;

public class CocaineRightclickedOnBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, ItemStack itemstack) {
		if (world.isEmptyBlock(BlockPos.containing(x, y + 1, z)) && ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == DrugsGemsModBlocks.COKE_PILE.get()) == false) {
			world.setBlock(BlockPos.containing(x, y + 1, z), DrugsGemsModBlocks.COKE_PILE.get().defaultBlockState(), 3);
			itemstack.shrink(1);
		}
	}
}