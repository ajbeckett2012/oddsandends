package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.drugsgems.init.DrugsGemsModMobEffects;
import net.mcreator.drugsgems.DrugsGemsMod;

public class MethPlayerFinishesUsingItemProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("overdose", (entity.getPersistentData().getDouble("overdose") + 3));
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.sniffer.sniffing")), SoundSource.NEUTRAL, 1, 2);
			} else {
				_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.sniffer.sniffing")), SoundSource.NEUTRAL, 1, 2, false);
			}
		}
		itemstack.shrink(1);
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 3, false, false));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(DrugsGemsModMobEffects.HIGH, 1200, 0, false, false));
		DrugsGemsMod.queueServerWork(1199, () -> {
			entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.MAGIC)), 19);
		});
		DrugsGemsMod.queueServerWork(2000, () -> {
			if (entity.getPersistentData().getDouble("overdose") > 0) {
				entity.getPersistentData().putDouble("overdose", (entity.getPersistentData().getDouble("overdose") - 3));
			}
		});
		if (entity.getPersistentData().getDouble("overdose") > 10) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(DrugsGemsModMobEffects.OVERDOSING_EFFECT, 2000, 1, false, false));
		}
	}
}