package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.drugsgems.init.DrugsGemsModItems;

public class LightingTheJointProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((world.getBlockState(BlockPos.containing(x, y, z))).is(BlockTags.create(ResourceLocation.parse("fire")))) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack2 = new ItemStack(DrugsGemsModItems.JOINT_LIT.get()).copy();
				_setstack2.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack2);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).is(BlockTags.create(ResourceLocation.parse("campfires")))) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack5 = new ItemStack(DrugsGemsModItems.JOINT_LIT.get()).copy();
				_setstack5.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack5);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.TORCH) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack8 = new ItemStack(DrugsGemsModItems.JOINT_LIT.get()).copy();
				_setstack8.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack8);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.WALL_TORCH) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack11 = new ItemStack(DrugsGemsModItems.JOINT_LIT.get()).copy();
				_setstack11.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack11);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.SOUL_TORCH) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack14 = new ItemStack(DrugsGemsModItems.JOINT_LIT.get()).copy();
				_setstack14.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack14);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.SOUL_WALL_TORCH) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack17 = new ItemStack(DrugsGemsModItems.JOINT_LIT.get()).copy();
				_setstack17.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack17);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
		}
	}
}