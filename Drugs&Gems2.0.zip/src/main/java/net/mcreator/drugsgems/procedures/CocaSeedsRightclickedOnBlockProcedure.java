package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;

import net.mcreator.drugsgems.init.DrugsGemsModBlocks;

public class CocaSeedsRightclickedOnBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, ItemStack itemstack) {
		double diamonds = 0;
		if (world.isEmptyBlock(BlockPos.containing(x, y + 1, z)) && (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.FARMLAND) {
			world.setBlock(BlockPos.containing(x, y + 1, z), DrugsGemsModBlocks.COCA_PLANT_STAGE_1.get().defaultBlockState(), 3);
			itemstack.shrink(1);
		}
	}
}