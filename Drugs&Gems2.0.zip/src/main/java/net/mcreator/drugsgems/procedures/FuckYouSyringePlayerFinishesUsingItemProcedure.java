package net.mcreator.drugsgems.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.LlamaSpit;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;

import net.mcreator.drugsgems.init.DrugsGemsModMobEffects;
import net.mcreator.drugsgems.DrugsGemsMod;

public class FuckYouSyringePlayerFinishesUsingItemProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		itemstack.shrink(1);
		entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.GENERIC)), 6);
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.HUNGER, 300, 5, false, true));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 300, 5, false, true));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 300, 5, false, true));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.POISON, 300, 5, false, true));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 300, 5, false, true));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(DrugsGemsModMobEffects.HIGH, 300, 0, false, true));
		DrugsGemsMod.queueServerWork(20, () -> {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 20, 5, false, true));
		});
		DrugsGemsMod.queueServerWork(100, () -> {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 20, 5, false, true));
			if (entity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.MAIN_HAND, true);
			{
				Entity _ent = entity;
				_ent.setYRot(12);
				_ent.setXRot(12);
				_ent.setYBodyRot(_ent.getYRot());
				_ent.setYHeadRot(_ent.getYRot());
				_ent.yRotO = _ent.getYRot();
				_ent.xRotO = _ent.getXRot();
				if (_ent instanceof LivingEntity _entity) {
					_entity.yBodyRotO = _entity.getYRot();
					_entity.yHeadRotO = _entity.getYRot();
				}
			}
		});
		DrugsGemsMod.queueServerWork(250, () -> {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 50, 5, false, true));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 20, 5, false, true));
			{
				Entity _ent = entity;
				_ent.setYRot(12);
				_ent.setXRot(12);
				_ent.setYBodyRot(_ent.getYRot());
				_ent.setYHeadRot(_ent.getYRot());
				_ent.yRotO = _ent.getYRot();
				_ent.xRotO = _ent.getXRot();
				if (_ent instanceof LivingEntity _entity) {
					_entity.yBodyRotO = _entity.getYRot();
					_entity.yHeadRotO = _entity.getYRot();
				}
			}
			if (entity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.MAIN_HAND, true);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.player.hurt_drown")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.player.hurt_drown")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
		});
		DrugsGemsMod.queueServerWork(300, () -> {
			{
				Entity _ent = entity;
				_ent.setYRot(12);
				_ent.setXRot(12);
				_ent.setYBodyRot(_ent.getYRot());
				_ent.setYHeadRot(_ent.getYRot());
				_ent.yRotO = _ent.getYRot();
				_ent.xRotO = _ent.getXRot();
				if (_ent instanceof LivingEntity _entity) {
					_entity.yBodyRotO = _entity.getYRot();
					_entity.yHeadRotO = _entity.getYRot();
				}
			}
		});
		DrugsGemsMod.queueServerWork(30, () -> {
			entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x + Mth.nextInt(RandomSource.create(), -100000, 100000)), (y + Mth.nextInt(RandomSource.create(), -60, 256)), (z + Mth.nextInt(RandomSource.create(), -100000, 100000))));
			{
				Entity _ent = entity;
				_ent.setYRot(12);
				_ent.setXRot(12);
				_ent.setYBodyRot(_ent.getYRot());
				_ent.setYHeadRot(_ent.getYRot());
				_ent.yRotO = _ent.getYRot();
				_ent.xRotO = _ent.getXRot();
				if (_ent instanceof LivingEntity _entity) {
					_entity.yBodyRotO = _entity.getYRot();
					_entity.yHeadRotO = _entity.getYRot();
				}
			}
		});
		DrugsGemsMod.queueServerWork(50, () -> {
			entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x + Mth.nextInt(RandomSource.create(), -100000, 100000)), (y + Mth.nextInt(RandomSource.create(), -60, 256)), (z + Mth.nextInt(RandomSource.create(), -100000, 100000))));
		});
		DrugsGemsMod.queueServerWork(70, () -> {
			entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x + Mth.nextInt(RandomSource.create(), -100000, 100000)), (y + Mth.nextInt(RandomSource.create(), -60, 256)), (z + Mth.nextInt(RandomSource.create(), -100000, 100000))));
			if (entity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.MAIN_HAND, true);
		});
		DrugsGemsMod.queueServerWork(90, () -> {
			entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x + Mth.nextInt(RandomSource.create(), -100000, 100000)), (y + Mth.nextInt(RandomSource.create(), -60, 256)), (z + Mth.nextInt(RandomSource.create(), -100000, 100000))));
		});
		DrugsGemsMod.queueServerWork(110, () -> {
			entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x + Mth.nextInt(RandomSource.create(), -100000, 100000)), (y + Mth.nextInt(RandomSource.create(), -60, 256)), (z + Mth.nextInt(RandomSource.create(), -100000, 100000))));
		});
		DrugsGemsMod.queueServerWork(130, () -> {
			entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x + Mth.nextInt(RandomSource.create(), -100000, 100000)), (y + Mth.nextInt(RandomSource.create(), -60, 256)), (z + Mth.nextInt(RandomSource.create(), -100000, 100000))));
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.glow_squid.squirt")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.glow_squid.squirt")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
			{
				Entity _shootFrom = entity;
				Level projectileLevel = _shootFrom.level();
				if (!projectileLevel.isClientSide()) {
					Projectile _entityToSpawn = new LlamaSpit(EntityType.LLAMA_SPIT, projectileLevel);
					_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
					_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 1, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
		});
		DrugsGemsMod.queueServerWork(150, () -> {
			entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.GENERIC)), 100);
		});
	}
}