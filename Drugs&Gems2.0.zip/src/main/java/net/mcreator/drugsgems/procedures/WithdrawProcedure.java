package net.mcreator.drugsgems.procedures;

import net.neoforged.neoforge.items.ItemHandlerHelper;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;

import net.mcreator.drugsgems.init.DrugsGemsModItems;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class WithdrawProcedure {
	public static void execute(CommandContext<CommandSourceStack> arguments, Entity entity) {
		if (entity == null)
			return;
		if (DoubleArgumentType.getDouble(arguments, "cash") <= entity.getPersistentData().getDouble("balance")) {
			if (entity instanceof Player _player) {
				ItemStack _setstack = new ItemStack(DrugsGemsModItems.CASH.get()).copy();
				_setstack.setCount((int) DoubleArgumentType.getDouble(arguments, "cash"));
				ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
			}
			entity.getPersistentData().putDouble("balance", (entity.getPersistentData().getDouble("balance") - DoubleArgumentType.getDouble(arguments, "cash")));
		} else {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Error: Cannot withdraw more cash than in account balance."), false);
		}
	}
}