package net.mcreator.drugsgems.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.drugsgems.init.DrugsGemsModMobEffects;

public class NarcanPlayerFinishesUsingItemProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(DrugsGemsModMobEffects.OVERDOSING_EFFECT)) {
			itemstack.shrink(1);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(DrugsGemsModMobEffects.OVERDOSING_EFFECT);
		}
	}
}