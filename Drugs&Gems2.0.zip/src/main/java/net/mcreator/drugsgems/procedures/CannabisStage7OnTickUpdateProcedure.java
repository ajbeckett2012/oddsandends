package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.drugsgems.init.DrugsGemsModBlocks;

public class CannabisStage7OnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		sx = -3;
		found = false;
		for (int index0 = 0; index0 < 10; index0++) {
			sy = -3;
			for (int index1 = 0; index1 < 10; index1++) {
				sz = -3;
				for (int index2 = 0; index2 < 10; index2++) {
					if ((world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == DrugsGemsModBlocks.FAN_ON.get()) {
						found = true;
					}
					sz = sz + 1;
				}
				sy = sy + 1;
			}
			sx = sx + 1;
		}
		if (found == true) {
			sy = 0;
			found = false;
			for (int index3 = 0; index3 < 6; index3++) {
				if ((world.getBlockState(BlockPos.containing(x, y + sy, z))).getBlock() == DrugsGemsModBlocks.UV_LIGHT_ON.get()) {
					found = true;
				}
				sy = sy + 1;
			}
			if (found == true) {
				if (world.isEmptyBlock(BlockPos.containing(x, y + 1, z))) {
					if (Math.random() < 0.1) {
						world.setBlock(BlockPos.containing(x, y + 1, z), DrugsGemsModBlocks.CANNABIS_2_STAGE_1.get().defaultBlockState(), 3);
					}
				}
			}
		}
	}
}