package net.mcreator.drugsgems.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;

import net.mcreator.drugsgems.init.DrugsGemsModMobEffects;
import net.mcreator.drugsgems.init.DrugsGemsModItems;
import net.mcreator.drugsgems.DrugsGemsMod;

public class BlackTarSyringePlayerFinishesUsingItemProcedure {
	public static void execute(LevelAccessor world, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("overdose", (entity.getPersistentData().getDouble("overdose") + 4));
		itemstack.shrink(1);
		entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.GENERIC)), 1);
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 6000, 2, false, false));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 6000, 1, false, false));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 1, false, false));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.POISON, 200, 0, false, false));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(DrugsGemsModMobEffects.HIGH, 8000, 0, false, false));
		DrugsGemsMod.queueServerWork(1, () -> {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack11 = new ItemStack(DrugsGemsModItems.SYRINGE.get()).copy();
				_setstack11.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack11);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
		});
		DrugsGemsMod.queueServerWork(5000, () -> {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 3000, 0, false, false));
		});
		DrugsGemsMod.queueServerWork(10000, () -> {
			if (entity.getPersistentData().getDouble("overdose") > 0) {
				entity.getPersistentData().putDouble("overdose", (entity.getPersistentData().getDouble("overdose") - 4));
			}
		});
		if (entity.getPersistentData().getDouble("overdose") > 10) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(DrugsGemsModMobEffects.OVERDOSING_EFFECT, 2000, 0, false, false));
		}
	}
}