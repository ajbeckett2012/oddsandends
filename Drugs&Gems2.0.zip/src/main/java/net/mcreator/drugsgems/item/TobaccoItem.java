package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class TobaccoItem extends Item {
	public TobaccoItem() {
		super(new Item.Properties());
	}
}