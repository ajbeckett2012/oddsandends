package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class OpalItem extends Item {
	public OpalItem() {
		super(new Item.Properties());
	}
}