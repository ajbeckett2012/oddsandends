package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class HeroinItem extends Item {
	public HeroinItem() {
		super(new Item.Properties());
	}
}