package net.mcreator.drugsgems.item;

import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.Item;
import net.minecraft.world.InteractionResult;

import net.mcreator.drugsgems.procedures.PackagedCokeRightclickedProcedure;

public class PackagedCokeItem extends Item {
	public PackagedCokeItem() {
		super(new Item.Properties().durability(5));
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		super.useOn(context);
		PackagedCokeRightclickedProcedure.execute(context.getLevel(), context.getClickedPos().getX(), context.getClickedPos().getY(), context.getClickedPos().getZ(), context.getItemInHand());
		return InteractionResult.SUCCESS;
	}
}