package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class RubyItem extends Item {
	public RubyItem() {
		super(new Item.Properties());
	}
}