package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class PeridotItem extends Item {
	public PeridotItem() {
		super(new Item.Properties());
	}
}