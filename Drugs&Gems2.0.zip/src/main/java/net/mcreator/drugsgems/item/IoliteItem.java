package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class IoliteItem extends Item {
	public IoliteItem() {
		super(new Item.Properties());
	}
}