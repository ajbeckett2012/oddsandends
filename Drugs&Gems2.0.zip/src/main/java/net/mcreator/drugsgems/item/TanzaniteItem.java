package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class TanzaniteItem extends Item {
	public TanzaniteItem() {
		super(new Item.Properties());
	}
}