package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class TobaccoLeavesItem extends Item {
	public TobaccoLeavesItem() {
		super(new Item.Properties());
	}
}