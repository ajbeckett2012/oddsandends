package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class MethanolItem extends Item {
	public MethanolItem() {
		super(new Item.Properties());
	}
}