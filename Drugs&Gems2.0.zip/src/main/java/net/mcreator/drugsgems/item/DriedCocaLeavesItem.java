package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class DriedCocaLeavesItem extends Item {
	public DriedCocaLeavesItem() {
		super(new Item.Properties());
	}
}