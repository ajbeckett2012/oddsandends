package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class AquamarineItem extends Item {
	public AquamarineItem() {
		super(new Item.Properties());
	}
}