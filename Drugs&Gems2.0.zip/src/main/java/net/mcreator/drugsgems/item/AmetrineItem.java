package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class AmetrineItem extends Item {
	public AmetrineItem() {
		super(new Item.Properties());
	}
}