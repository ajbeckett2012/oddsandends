package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class DriedTobaccoLeavesItem extends Item {
	public DriedTobaccoLeavesItem() {
		super(new Item.Properties());
	}
}