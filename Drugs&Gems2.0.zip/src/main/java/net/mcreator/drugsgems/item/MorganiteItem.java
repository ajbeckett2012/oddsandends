package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class MorganiteItem extends Item {
	public MorganiteItem() {
		super(new Item.Properties());
	}
}