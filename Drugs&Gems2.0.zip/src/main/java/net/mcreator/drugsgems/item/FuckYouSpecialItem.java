package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class FuckYouSpecialItem extends Item {
	public FuckYouSpecialItem() {
		super(new Item.Properties().rarity(Rarity.UNCOMMON));
	}
}