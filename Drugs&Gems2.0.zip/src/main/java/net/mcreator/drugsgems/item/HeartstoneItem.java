package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class HeartstoneItem extends Item {
	public HeartstoneItem() {
		super(new Item.Properties());
	}
}