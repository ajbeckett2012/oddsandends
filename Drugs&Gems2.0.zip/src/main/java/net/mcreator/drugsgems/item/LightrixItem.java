package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class LightrixItem extends Item {
	public LightrixItem() {
		super(new Item.Properties());
	}
}