package net.mcreator.drugsgems.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class SyringeItem extends Item {
	public SyringeItem() {
		super(new Item.Properties());
	}

	@Override
	public boolean hasCraftingRemainingItem(ItemStack stack) {
		return true;
	}

	@Override
	public ItemStack getCraftingRemainingItem(ItemStack itemstack) {
		return new ItemStack(this);
	}
}