package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class TopazItem extends Item {
	public TopazItem() {
		super(new Item.Properties());
	}
}