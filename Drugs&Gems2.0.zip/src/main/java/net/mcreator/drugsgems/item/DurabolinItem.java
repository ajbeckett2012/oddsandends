package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class DurabolinItem extends Item {
	public DurabolinItem() {
		super(new Item.Properties());
	}
}