package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class PaleDiamondItem extends Item {
	public PaleDiamondItem() {
		super(new Item.Properties());
	}
}