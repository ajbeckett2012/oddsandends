package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class JadeItem extends Item {
	public JadeItem() {
		super(new Item.Properties());
	}
}