package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class GarnetItem extends Item {
	public GarnetItem() {
		super(new Item.Properties());
	}
}