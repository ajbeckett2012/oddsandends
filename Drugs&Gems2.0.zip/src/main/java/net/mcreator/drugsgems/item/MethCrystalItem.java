package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class MethCrystalItem extends Item {
	public MethCrystalItem() {
		super(new Item.Properties());
	}
}