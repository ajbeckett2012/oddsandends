package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class ChinaWhiteHeroinItem extends Item {
	public ChinaWhiteHeroinItem() {
		super(new Item.Properties());
	}
}