package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class BlackOpalItem extends Item {
	public BlackOpalItem() {
		super(new Item.Properties());
	}
}