package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class CannabisItem extends Item {
	public CannabisItem() {
		super(new Item.Properties());
	}
}