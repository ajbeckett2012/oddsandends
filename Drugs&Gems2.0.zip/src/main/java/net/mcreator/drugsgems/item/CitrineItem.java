package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class CitrineItem extends Item {
	public CitrineItem() {
		super(new Item.Properties());
	}
}