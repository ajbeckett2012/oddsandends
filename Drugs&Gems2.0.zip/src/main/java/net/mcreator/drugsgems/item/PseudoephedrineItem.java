package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class PseudoephedrineItem extends Item {
	public PseudoephedrineItem() {
		super(new Item.Properties());
	}
}