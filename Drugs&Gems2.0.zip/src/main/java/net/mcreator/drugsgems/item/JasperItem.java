package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class JasperItem extends Item {
	public JasperItem() {
		super(new Item.Properties());
	}
}