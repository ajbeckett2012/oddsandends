package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class ZirconItem extends Item {
	public ZirconItem() {
		super(new Item.Properties());
	}
}