package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class PlasticItem extends Item {
	public PlasticItem() {
		super(new Item.Properties());
	}
}