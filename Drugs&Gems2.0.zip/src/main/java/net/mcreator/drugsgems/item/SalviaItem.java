package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class SalviaItem extends Item {
	public SalviaItem() {
		super(new Item.Properties());
	}
}