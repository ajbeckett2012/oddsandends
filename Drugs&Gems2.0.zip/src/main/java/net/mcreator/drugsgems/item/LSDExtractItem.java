package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class LSDExtractItem extends Item {
	public LSDExtractItem() {
		super(new Item.Properties());
	}
}