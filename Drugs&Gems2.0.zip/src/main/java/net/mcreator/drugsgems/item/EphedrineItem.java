package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class EphedrineItem extends Item {
	public EphedrineItem() {
		super(new Item.Properties());
	}
}