package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class KunziteItem extends Item {
	public KunziteItem() {
		super(new Item.Properties());
	}
}