package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class CocaLeavesItem extends Item {
	public CocaLeavesItem() {
		super(new Item.Properties());
	}
}