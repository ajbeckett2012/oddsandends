package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class TourmalineItem extends Item {
	public TourmalineItem() {
		super(new Item.Properties());
	}
}