package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class AlexandriteItem extends Item {
	public AlexandriteItem() {
		super(new Item.Properties());
	}
}