package net.mcreator.drugsgems.item;

import net.minecraft.world.item.Item;

public class BlackTarHeroinItem extends Item {
	public BlackTarHeroinItem() {
		super(new Item.Properties());
	}
}