package net.mcreator.drugsgems.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.drugsgems.entity.HatManEntity;
import net.mcreator.drugsgems.client.model.ModelHatMan;

public class HatManRenderer extends MobRenderer<HatManEntity, ModelHatMan<HatManEntity>> {
	public HatManRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelHatMan<HatManEntity>(context.bakeLayer(ModelHatMan.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(HatManEntity entity) {
		return ResourceLocation.parse("drugs__gems:textures/entities/hatman.png");
	}

	@Override
	protected boolean isShaking(HatManEntity entity) {
		return true;
	}
}