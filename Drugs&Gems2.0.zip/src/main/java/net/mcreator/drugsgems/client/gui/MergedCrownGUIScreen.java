package net.mcreator.drugsgems.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.drugsgems.world.inventory.MergedCrownGUIMenu;
import net.mcreator.drugsgems.network.MergedCrownGUIButtonMessage;
import net.mcreator.drugsgems.init.DrugsGemsModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class MergedCrownGUIScreen extends AbstractContainerScreen<MergedCrownGUIMenu> implements DrugsGemsModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_activate;
	private Button button_activate1;
	private Button button_activate2;
	private Button button_activate3;

	public MergedCrownGUIScreen(MergedCrownGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 240;
		this.imageHeight = 120;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("drugs__gems:textures/screens/merged_crown_gui.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		boolean customTooltipShown = false;
		if (mouseX > leftPos + 8 && mouseX < leftPos + 112 && mouseY > topPos + 12 && mouseY < topPos + 28) {
			guiGraphics.renderTooltip(font, Component.translatable("gui.drugs__gems.merged_crown_gui.tooltip_become_immune_to_fire_and_recei"), mouseX, mouseY);
			customTooltipShown = true;
		}
		if (mouseX > leftPos + 152 && mouseX < leftPos + 224 && mouseY > topPos + 12 && mouseY < topPos + 28) {
			guiGraphics.renderTooltip(font, Component.translatable("gui.drugs__gems.merged_crown_gui.tooltip_fall_from_any_height_and_harness"), mouseX, mouseY);
			customTooltipShown = true;
		}
		if (mouseX > leftPos + 24 && mouseX < leftPos + 96 && mouseY > topPos + 68 && mouseY < topPos + 84) {
			guiGraphics.renderTooltip(font, Component.translatable("gui.drugs__gems.merged_crown_gui.tooltip_increase_your_swiftness_forcing"), mouseX, mouseY);
			customTooltipShown = true;
		}
		if (mouseX > leftPos + 136 && mouseX < leftPos + 232 && mouseY > topPos + 68 && mouseY < topPos + 84) {
			guiGraphics.renderTooltip(font, Component.translatable("gui.drugs__gems.merged_crown_gui.tooltip_be_granted_the_blessings_of_dark"), mouseX, mouseY);
			customTooltipShown = true;
		}
		if (!customTooltipShown)
			this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.drugs__gems.merged_crown_gui.label_strength_of_hellfire"), 8, 12, -12517376, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.drugs__gems.merged_crown_gui.label_alien_essence"), 152, 12, -14024627, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.drugs__gems.merged_crown_gui.label_gifts_of_the_wicked"), 136, 68, -12375552, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.drugs__gems.merged_crown_gui.label_evasive_nature"), 24, 68, -13684945, false);
	}

	@Override
	public void init() {
		super.init();
		button_activate = Button.builder(Component.translatable("gui.drugs__gems.merged_crown_gui.button_activate"), e -> {
			int x = MergedCrownGUIScreen.this.x;
			int y = MergedCrownGUIScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new MergedCrownGUIButtonMessage(0, x, y, z));
				MergedCrownGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 24, this.topPos + 28, 67, 20).build();
		this.addRenderableWidget(button_activate);
		button_activate1 = Button.builder(Component.translatable("gui.drugs__gems.merged_crown_gui.button_activate1"), e -> {
			int x = MergedCrownGUIScreen.this.x;
			int y = MergedCrownGUIScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new MergedCrownGUIButtonMessage(1, x, y, z));
				MergedCrownGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 152, this.topPos + 28, 67, 20).build();
		this.addRenderableWidget(button_activate1);
		button_activate2 = Button.builder(Component.translatable("gui.drugs__gems.merged_crown_gui.button_activate2"), e -> {
			int x = MergedCrownGUIScreen.this.x;
			int y = MergedCrownGUIScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new MergedCrownGUIButtonMessage(2, x, y, z));
				MergedCrownGUIButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}).bounds(this.leftPos + 24, this.topPos + 84, 67, 20).build();
		this.addRenderableWidget(button_activate2);
		button_activate3 = Button.builder(Component.translatable("gui.drugs__gems.merged_crown_gui.button_activate3"), e -> {
			int x = MergedCrownGUIScreen.this.x;
			int y = MergedCrownGUIScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new MergedCrownGUIButtonMessage(3, x, y, z));
				MergedCrownGUIButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}).bounds(this.leftPos + 152, this.topPos + 84, 67, 20).build();
		this.addRenderableWidget(button_activate3);
	}
}