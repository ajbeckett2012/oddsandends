package net.mcreator.drugsgems.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.drugsgems.entity.TweakerEntity;
import net.mcreator.drugsgems.client.model.animations.TweakerAnimation;
import net.mcreator.drugsgems.client.model.ModelTweaker;

public class TweakerRenderer extends MobRenderer<TweakerEntity, ModelTweaker<TweakerEntity>> {
	public TweakerRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelTweaker.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(TweakerEntity entity) {
		return ResourceLocation.parse("drugs__gems:textures/entities/tweaker.png");
	}

	private static final class AnimatedModel extends ModelTweaker<TweakerEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<TweakerEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(TweakerEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animateWalk(TweakerAnimation.walking, limbSwing, limbSwingAmount, 1f, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(TweakerEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}